package com.harindra.tvlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager

object BlackCurtainOverlay {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var overlayView: View? = null
    private var wm: WindowManager? = null

    private val autoHideRunnable = Runnable { hideNow() }

    fun canDraw(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else true
    }

    fun show(context: Context) {
        if (!canDraw(context)) return
        mainHandler.post {
            try {
                if (overlayView != null) {
                    mainHandler.removeCallbacks(autoHideRunnable)
                    mainHandler.postDelayed(autoHideRunnable, 1400L)
                    return@post
                }
                val appCtx = context.applicationContext
                val manager = appCtx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                } else {
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE
                }
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    PixelFormat.OPAQUE
                )
                val curtain = View(appCtx).apply {
                    setBackgroundColor(Color.parseColor("#0E1117"))
                }
                manager.addView(curtain, params)
                wm = manager
                overlayView = curtain
                // Safety auto-hide so screen can NEVER get stuck black!
                mainHandler.removeCallbacks(autoHideRunnable)
                mainHandler.postDelayed(autoHideRunnable, 1400L)
            } catch (_: Throwable) { }
        }
    }

    fun hideSoon() {
        mainHandler.removeCallbacks(autoHideRunnable)
        mainHandler.postDelayed({ hideNow() }, 70L)
    }

    fun hideNow() {
        mainHandler.post {
            mainHandler.removeCallbacks(autoHideRunnable)
            val v = overlayView ?: return@post
            try {
                wm?.removeViewImmediate(v)
            } catch (_: Throwable) {
                try { wm?.removeView(v) } catch (_: Throwable) { }
            }
            overlayView = null
            wm = null
        }
    }
}
