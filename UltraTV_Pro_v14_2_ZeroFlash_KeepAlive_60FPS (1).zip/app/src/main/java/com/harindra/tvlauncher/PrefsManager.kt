package com.harindra.tvlauncher

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

class PrefsManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("ultratv_pro_v6_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_PINNED = "pinned_apps_csv"
        private const val KEY_HIDDEN = "hidden_apps_csv"
        private const val KEY_LOCKED = "locked_apps_csv"
        private const val KEY_RECENT = "recent_apps_csv"
        private const val KEY_FAV_CHANNELS = "fav_channels_csv"
        private const val KEY_THEME = "theme_index"
        private const val KEY_SHOW_HERO = "show_hero"
        private const val KEY_SHOW_RAM = "show_ram"
        private const val KEY_24H_CLOCK = "clock_24h"
        private const val KEY_GRID_COLS = "grid_cols"
        private const val KEY_BOOT_MODE = "boot_mode"
        private const val KEY_AUTO_LAUNCH_PKG = "auto_launch_pkg"
        private const val KEY_ULTRA_LITE = "ultra_lite_mode"
        private const val KEY_AUTO_RAM_GUARD = "auto_ram_guard"
        private const val KEY_4D_ANIM = "enable_4d_anim"
        private const val KEY_M3U_URL = "m3u_url"
        private const val KEY_IPTV_PLAYER_PKG = "iptv_player_pkg"
        private const val KEY_LAST_CHANNEL_URL = "last_channel_url"
        private const val KEY_LAST_CHANNEL_NAME = "last_channel_name"
        private const val KEY_KIDS_PIN = "kids_pin"
        private const val KEY_SPEED_DIAL_PREFIX = "speed_dial_"
        private const val KEY_YT_HISTORY_JSON = "yt_watch_history_json"
        private const val KEY_IPTV_HISTORY_JSON = "iptv_watch_history_json"
        private const val KEY_LAST_YT_MEDIA_TITLE = "last_yt_media_title"
        private const val KEY_LAST_YT_MEDIA_CHANNEL = "last_yt_media_channel"
        private const val KEY_LAST_YT_MEDIA_TIME = "last_yt_media_time"
        private const val KEY_LAST_IPTV_MEDIA_TITLE = "last_iptv_media_title"
        private const val KEY_LAST_IPTV_MEDIA_PKG = "last_iptv_media_pkg"
        private const val KEY_LAST_IPTV_MEDIA_TIME = "last_iptv_media_time"

        private const val KEY_MB_HISTORY_JSON = "mb_watch_history_json"
        private const val KEY_LAST_MB_TITLE = "last_mb_media_title"
        private const val KEY_LAST_MB_PKG = "last_mb_media_pkg"
        private const val KEY_LAST_MB_TIME = "last_mb_media_time"
        private const val KEY_SHOW_SIDEBAR = "show_left_sidebar"
        private const val KEY_SHOW_MOVIEBOX = "show_moviebox_row"
        private const val KEY_CACHED_APPS_JSON = "cached_apps_fastboot_json"
        private const val KEY_PERF_TIER = "perf_tier_mode"
        private const val KEY_FAV_MOVIES = "fav_movies_csv"
        private const val KEY_BOOT_DIAG = "last_boot_diag"
        private const val KEY_MAP_HOME_ENABLED = "btn_map_home_enabled"
        private const val KEY_MAP_CUSTOM_PREFIX = "btn_map_keycode_"
        private const val KEY_KEEP_ALIVE = "keep_alive_service_enabled"
        private const val KEY_WAKE_TO_ULTRA = "wake_to_ultratv_enabled"

    }

    fun getPinnedPackages(): MutableList<String> = readCsvList(KEY_PINNED)
    fun savePinnedPackages(list: List<String>) = saveCsv(KEY_PINNED, list.distinct())

    fun getHiddenPackages(): MutableSet<String> = readCsvList(KEY_HIDDEN).toMutableSet()
    fun saveHiddenPackages(set: Set<String>) = saveCsv(KEY_HIDDEN, set.toList())

    fun getLockedPackages(): MutableSet<String> = readCsvList(KEY_LOCKED).toMutableSet()
    fun saveLockedPackages(set: Set<String>) = saveCsv(KEY_LOCKED, set.toList())

    fun getFavoriteChannelIds(): MutableSet<String> = readCsvList(KEY_FAV_CHANNELS).toMutableSet()
    fun saveFavoriteChannelIds(set: Set<String>) = saveCsv(KEY_FAV_CHANNELS, set.toList())

    fun getRecentPackages(): MutableList<String> = readCsvList(KEY_RECENT)
    fun recordRecentPackage(pkg: String) {
        val list = getRecentPackages()
        list.remove(pkg)
        list.add(0, pkg)
        saveCsv(KEY_RECENT, if (list.size > 12) list.subList(0, 12) else list)
    }

    fun recordYouTubeWatch(video: YouTubeVideo) {
        val list = getYouTubeHistory().toMutableList()
        list.removeAll { it.videoId == video.videoId }
        list.add(0, video.copy(watchedAtMs = System.currentTimeMillis()))
        val trimmed = list.take(12)
        val arr = JSONArray()
        for (v in trimmed) {
            arr.put(JSONObject().apply {
                put("id", v.videoId)
                put("title", v.title)
                put("channel", v.channelName)
                put("cat", v.category)
                put("ts", v.watchedAtMs)
            })
        }
        prefs.edit().putString(KEY_YT_HISTORY_JSON, arr.toString()).apply()
    }

    fun getYouTubeHistory(): List<YouTubeVideo> {
        val raw = prefs.getString(KEY_YT_HISTORY_JSON, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<YouTubeVideo>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val id = o.optString("id")
                if (id.isNotBlank()) {
                    out.add(
                        YouTubeVideo(
                            videoId = id,
                            title = o.optString("title", "YouTube Video"),
                            channelName = o.optString("channel", "YouTube"),
                            category = o.optString("cat", "Continue"),
                            watchedAtMs = o.optLong("ts", System.currentTimeMillis())
                        )
                    )
                }
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun saveDetectedYouTubeMedia(title: String, channel: String) {
        if (title.isBlank()) return
        prefs.edit()
            .putString(KEY_LAST_YT_MEDIA_TITLE, title.trim())
            .putString(KEY_LAST_YT_MEDIA_CHANNEL, channel.trim())
            .putLong(KEY_LAST_YT_MEDIA_TIME, System.currentTimeMillis())
            .apply()
    }

    fun getDetectedYouTubeMedia(): Triple<String, String, Long>? {
        val title = prefs.getString(KEY_LAST_YT_MEDIA_TITLE, "") ?: ""
        if (title.isBlank()) return null
        val ch = prefs.getString(KEY_LAST_YT_MEDIA_CHANNEL, "YouTube") ?: "YouTube"
        val ts = prefs.getLong(KEY_LAST_YT_MEDIA_TIME, 0L)
        return Triple(title, ch, ts)
    }

    fun saveDetectedIptvMedia(title: String, pkg: String) {
        if (title.isBlank()) return
        prefs.edit()
            .putString(KEY_LAST_IPTV_MEDIA_TITLE, title.trim())
            .putString(KEY_LAST_IPTV_MEDIA_PKG, pkg.trim())
            .putLong(KEY_LAST_IPTV_MEDIA_TIME, System.currentTimeMillis())
            .apply()
    }

    fun getDetectedIptvMedia(): Triple<String, String, Long>? {
        val title = prefs.getString(KEY_LAST_IPTV_MEDIA_TITLE, "") ?: ""
        if (title.isBlank()) return null
        val pkg = prefs.getString(KEY_LAST_IPTV_MEDIA_PKG, "com.harindra.iptvpro") ?: "com.harindra.iptvpro"
        val ts = prefs.getLong(KEY_LAST_IPTV_MEDIA_TIME, 0L)
        return Triple(title, pkg, ts)
    }

    fun recordIptvChannelWatch(ch: LiveChannel) {
        lastChannelUrl = ch.streamUrl
        lastChannelName = ch.name
        val list = getIptvHistory().toMutableList()
        list.removeAll { it.streamUrl == ch.streamUrl }
        list.add(0, ch)
        val trimmed = list.take(12)
        val arr = JSONArray()
        for (item in trimmed) {
            arr.put(JSONObject().apply {
                put("id", item.id)
                put("name", item.name)
                put("group", item.group)
                put("logo", item.logoUrl)
                put("url", item.streamUrl)
                put("ua", item.userAgent)
                put("ref", item.referrer)
            })
        }
        prefs.edit().putString(KEY_IPTV_HISTORY_JSON, arr.toString()).apply()
    }

    fun getIptvHistory(): List<LiveChannel> {
        val raw = prefs.getString(KEY_IPTV_HISTORY_JSON, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<LiveChannel>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val url = o.optString("url")
                if (url.isNotBlank()) {
                    out.add(
                        LiveChannel(
                            id = o.optString("id", "ch_$i"),
                            name = o.optString("name", "Live Channel"),
                            group = o.optString("group", "RAM PLAYER IPTV"),
                            logoUrl = o.optString("logo", ""),
                            streamUrl = url,
                            userAgent = o.optString("ua", ""),
                            referrer = o.optString("ref", "")
                        )
                    )
                }
            }
            out
        } catch (_: Throwable) {
            emptyList()
        }
    }

    fun setSpeedDial(digit: Int, target: String) {
        prefs.edit().putString(KEY_SPEED_DIAL_PREFIX + digit, target).apply()
    }

    fun getSpeedDial(digit: Int): String =
        prefs.getString(KEY_SPEED_DIAL_PREFIX + digit, "") ?: ""

    fun findSpeedDialDigit(target: String): Int? {
        for (d in 1..9) {
            if (getSpeedDial(d) == target) return d
        }
        return null
    }

    private fun readCsvList(key: String): MutableList<String> {
        val raw = prefs.getString(key, "") ?: ""
        return if (raw.isBlank()) mutableListOf()
        else raw.split("||").filter { it.isNotBlank() }.toMutableList()
    }

    private fun saveCsv(key: String, list: List<String>) {
        prefs.edit().putString(key, list.joinToString("||")).apply()
    }

    var themeIndex: Int
        get() = prefs.getInt(KEY_THEME, 0)
        set(value) = prefs.edit().putInt(KEY_THEME, value).apply()

    var showHeroBanner: Boolean
        get() = prefs.getBoolean(KEY_SHOW_HERO, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_HERO, value).apply()

    var showRamMeter: Boolean
        get() = prefs.getBoolean(KEY_SHOW_RAM, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_RAM, value).apply()

    var is24HourClock: Boolean
        get() = prefs.getBoolean(KEY_24H_CLOCK, false)
        set(value) = prefs.edit().putBoolean(KEY_24H_CLOCK, value).apply()

    var gridColumns: Int
        get() = prefs.getInt(KEY_GRID_COLS, 5)
        set(value) = prefs.edit().putInt(KEY_GRID_COLS, value).apply()

    var bootMode: Int
        get() = prefs.getInt(KEY_BOOT_MODE, 0)
        set(value) = prefs.edit().putInt(KEY_BOOT_MODE, value).apply()

    var autoLaunchPackage: String
        get() = prefs.getString(KEY_AUTO_LAUNCH_PKG, "") ?: ""
        set(value) = prefs.edit().putString(KEY_AUTO_LAUNCH_PKG, value).apply()

    var isUltraLiteMode: Boolean
        get() = prefs.getBoolean(KEY_ULTRA_LITE, false)
        set(value) = prefs.edit().putBoolean(KEY_ULTRA_LITE, value).apply()

    var isAutoRamGuard: Boolean
        get() = prefs.getBoolean(KEY_AUTO_RAM_GUARD, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_RAM_GUARD, value).apply()

    var enable4dAnimations: Boolean
        get() = prefs.getBoolean(KEY_4D_ANIM, true)
        set(value) = prefs.edit().putBoolean(KEY_4D_ANIM, value).apply()

    var m3uUrl: String
        get() = prefs.getString(KEY_M3U_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_M3U_URL, value).apply()

    var preferredIptvPlayer: String
        get() = prefs.getString(KEY_IPTV_PLAYER_PKG, "") ?: ""
        set(value) = prefs.edit().putString(KEY_IPTV_PLAYER_PKG, value).apply()

    var lastChannelUrl: String
        get() = prefs.getString(KEY_LAST_CHANNEL_URL, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_CHANNEL_URL, value).apply()

    var lastChannelName: String
        get() = prefs.getString(KEY_LAST_CHANNEL_NAME, "") ?: ""
        set(value) = prefs.edit().putString(KEY_LAST_CHANNEL_NAME, value).apply()

    var kidsPin: String
        get() = prefs.getString(KEY_KIDS_PIN, "1234") ?: "1234"
        set(value) = prefs.edit().putString(KEY_KIDS_PIN, value).apply()


    // ---- Instant Boot Cached App List (<50ms first frame!) ----
    fun saveCachedApps(apps: List<AppItem>) {
        val arr = JSONArray()
        for (a in apps.take(40)) {
            arr.put(JSONObject().apply {
                put("p", a.packageName)
                put("l", a.label)
                put("t", a.isTvApp)
                put("v", a.isLiveTvCandidate)
            })
        }
        prefs.edit().putString(KEY_CACHED_APPS_JSON, arr.toString()).apply()
    }

    fun getCachedApps(): List<AppItem> {
        val raw = prefs.getString(KEY_CACHED_APPS_JSON, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<AppItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(AppItem(o.optString("p"), o.optString("l"), o.optBoolean("t"), o.optBoolean("v")))
            }
            out
        } catch (_: Throwable) { emptyList() }
    }

    // ---- MovieBox Watch History (survives TV power-off!) ----
    fun recordMovieBoxWatch(item: MovieBoxItem) {
        val list = getMovieBoxHistory().toMutableList()
        list.removeAll { it.title.equals(item.title, true) }
        list.add(0, item.copy(watchedAtMs = System.currentTimeMillis()))
        val arr = JSONArray()
        for (m in list.take(12)) {
            arr.put(JSONObject().apply {
                put("id", m.id)
                put("title", m.title)
                put("meta", m.meta)
                put("rating", m.rating)
                put("cat", m.category)
                put("res", m.posterResId)
                put("url", m.posterUrl)
                put("tr", m.trailerVideoId)
                put("dl", m.deepLinkUri)
                put("sid", m.subjectId)
                put("dp", m.detailPath)
                put("ts", m.watchedAtMs)
            })
        }
        prefs.edit().putString(KEY_MB_HISTORY_JSON, arr.toString()).apply()
    }

    fun getMovieBoxHistory(): List<MovieBoxItem> {
        val raw = prefs.getString(KEY_MB_HISTORY_JSON, "") ?: ""
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            val out = mutableListOf<MovieBoxItem>()
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val t = o.optString("title")
                if (t.isNotBlank()) {
                    out.add(
                        MovieBoxItem(
                            id = o.optString("id", "mb_$i"),
                            title = t,
                            meta = o.optString("meta", "MovieBox • Continue Watching"),
                            rating = o.optString("rating", "★ HD"),
                            category = o.optString("cat", "Movies"),
                            posterResId = o.optInt("res", R.drawable.hero_superhero_4k),
                            posterUrl = o.optString("url", ""),
                            trailerVideoId = o.optString("tr", ""),
                            deepLinkUri = o.optString("dl", ""),
                            subjectId = o.optString("sid", ""),
                            detailPath = o.optString("dp", ""),
                            watchedAtMs = o.optLong("ts", System.currentTimeMillis())
                        )
                    )
                }
            }
            out
        } catch (_: Throwable) { emptyList() }
    }

    fun saveDetectedMovieBoxMedia(title: String, pkg: String) {
        if (title.isBlank()) return
        prefs.edit()
            .putString(KEY_LAST_MB_TITLE, title.trim())
            .putString(KEY_LAST_MB_PKG, pkg.trim())
            .putLong(KEY_LAST_MB_TIME, System.currentTimeMillis())
            .apply()
    }

    fun getDetectedMovieBoxMedia(): Triple<String, String, Long>? {
        val title = prefs.getString(KEY_LAST_MB_TITLE, "") ?: ""
        if (title.isBlank()) return null
        val pkg = prefs.getString(KEY_LAST_MB_PKG, "") ?: ""
        val ts = prefs.getLong(KEY_LAST_MB_TIME, 0L)
        return Triple(title, pkg, ts)
    }

    var showLeftSidebar: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SIDEBAR, false)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_SIDEBAR, value).apply()

    var showMovieBoxRow: Boolean
        get() = prefs.getBoolean(KEY_SHOW_MOVIEBOX, true)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_MOVIEBOX, value).apply()


    var performanceTier: Int
        get() = prefs.getInt(KEY_PERF_TIER, -1)
        set(value) = prefs.edit().putInt(KEY_PERF_TIER, value).apply()

    fun getFavoriteMovieTitles(): MutableSet<String> = readCsvList(KEY_FAV_MOVIES).toMutableSet()
    fun saveFavoriteMovieTitles(set: Set<String>) = saveCsv(KEY_FAV_MOVIES, set.toList())

    fun recordBootDiagnostic(ts: String, trigger: String, status: String) {
        prefs.edit().putString(KEY_BOOT_DIAG, "$ts | $trigger -> $status").apply()
    }

    fun getBootDiagnosticSummary(): String =
        prefs.getString(KEY_BOOT_DIAG, "No boot event recorded yet (Ready)") ?: "Ready"


    var mapHomeToUltraTv: Boolean
        get() = prefs.getBoolean(KEY_MAP_HOME_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_MAP_HOME_ENABLED, value).apply()

    // Maps any Android KeyEvent keyCode -> "ultratv_home", "tv_settings", or "pkg:<packageName>"
    fun setButtonMapping(keyCode: Int, target: String) {
        prefs.edit().putString(KEY_MAP_CUSTOM_PREFIX + keyCode, target).apply()
    }

    fun getButtonMapping(keyCode: Int): String =
        prefs.getString(KEY_MAP_CUSTOM_PREFIX + keyCode, "") ?: ""

    fun clearButtonMapping(keyCode: Int) {
        prefs.edit().remove(KEY_MAP_CUSTOM_PREFIX + keyCode).apply()
    }


    var keepAliveEnabled: Boolean
        get() = prefs.getBoolean(KEY_KEEP_ALIVE, true)
        set(value) = prefs.edit().putBoolean(KEY_KEEP_ALIVE, value).apply()

    var wakeToUltraTvEnabled: Boolean
        get() = prefs.getBoolean(KEY_WAKE_TO_ULTRA, true)
        set(value) = prefs.edit().putBoolean(KEY_WAKE_TO_ULTRA, value).apply()
}
